Save Format v3.0(19990112)
appname "universidad";
applib "universidad.pbl";
liblist "universidad.pbl";
type "pb";

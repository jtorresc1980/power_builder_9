Save Format v3.0(19990112)
appname "sistema_jugueteria";
applib "sistema_jugueteria.pbl";
liblist "sistema_jugueteria.pbl";
type "pb";
